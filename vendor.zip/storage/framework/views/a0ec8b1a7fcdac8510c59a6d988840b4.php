<?php if (isset($component)) { $__componentOriginale0f1cdd055772eb1d4a99981c240763e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0f1cdd055772eb1d4a99981c240763e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-layout','data' => ['pageTitle' => $guru->exists ? 'Edit Data Guru BK' : 'Daftar Guru BK Baru','pageSubtitle' => 'Silakan lengkapi detail informasi profil di bawah ini.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['pageTitle' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($guru->exists ? 'Edit Data Guru BK' : 'Daftar Guru BK Baru'),'pageSubtitle' => 'Silakan lengkapi detail informasi profil di bawah ini.']); ?>

    <div class="max-w-2xl bg-white rounded-2xl border border-slate-100 shadow-sm p-6">
        <form action="<?php echo e($guru->exists ? route('admin.guru-bk.update', $guru->id) : route('admin.guru-bk.store')); ?>" method="POST" class="space-y-5">
            <?php echo csrf_field(); ?>
            <?php if($guru->exists): ?>
                <?php echo method_field('PUT'); ?>
            <?php endif; ?>

            
            <div>
                <label for="name" class="block text-xs font-semibold text-slate-500 mb-1.5">Nama Lengkap beserta Gelar</label>
                <input type="text" name="name" id="name" value="<?php echo e(old('name', $guru->name)); ?>"
                       placeholder="Contoh: Siti Rahayu, M.Psi" required
                       class="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:border-teal-500 focus:ring-1 focus:ring-teal-500 outline-none transition text-slate-700">
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-rose-500 text-[10px] mt-1 block"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div>
                <label for="nip" class="block text-xs font-semibold text-slate-500 mb-1.5">Nomor Induk Pegawai (NIP)</label>
                <input type="text" name="nip" id="nip" value="<?php echo e(old('nip', $guru->nip)); ?>"
                       placeholder="Contoh: BK-001" required
                       class="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:border-teal-500 focus:ring-1 focus:ring-teal-500 outline-none transition text-slate-700 font-mono">
                <?php $__errorArgs = ['nip'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-rose-500 text-[10px] mt-1 block"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div>
                <label for="email" class="block text-xs font-semibold text-slate-500 mb-1.5">Alamat Email</label>
                <input type="email" name="email" id="email" value="<?php echo e(old('email', $guru->email)); ?>"
                       placeholder="Contoh: guru@test.com" required
                       class="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:border-teal-500 focus:ring-1 focus:ring-teal-500 outline-none transition text-slate-700">
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-rose-500 text-[10px] mt-1 block"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div>
                <label for="gender" class="block text-xs font-semibold text-slate-500 mb-1.5">Jenis Kelamin</label>
                <select name="gender" id="gender" required
                        class="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:border-teal-500 focus:ring-1 focus:ring-teal-500 outline-none transition text-slate-700">
                    <option value="">Pilih Jenis Kelamin</option>
                    <option value="L" <?php echo e(old('gender', $guru->gender) === 'L' ? 'selected' : ''); ?>>Laki-laki</option>
                    <option value="P" <?php echo e(old('gender', $guru->gender) === 'P' ? 'selected' : ''); ?>>Perempuan</option>
                </select>
                <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-rose-500 text-[10px] mt-1 block"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div>
                <label for="password" class="block text-xs font-semibold text-slate-500 mb-1.5">
                    Kata Sandi <?php echo e($guru->exists ? '(Biarkan kosong jika tidak diubah)' : ''); ?>

                </label>
                <input type="password" name="password" id="password" <?php echo e($guru->exists ? '' : 'required'); ?>

                       placeholder="Min. 8 karakter"
                       class="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:border-teal-500 focus:ring-1 focus:ring-teal-500 outline-none transition text-slate-700">
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-rose-500 text-[10px] mt-1 block"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div>
                <label for="password_confirmation" class="block text-xs font-semibold text-slate-500 mb-1.5">Konfirmasi Kata Sandi</label>
                <input type="password" name="password_confirmation" id="password_confirmation" <?php echo e($guru->exists ? '' : 'required'); ?>

                       placeholder="Ulangi Kata Sandi"
                       class="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:border-teal-500 focus:ring-1 focus:ring-teal-500 outline-none transition text-slate-700">
            </div>

            
            <div class="flex items-center gap-3 pt-3">
                <button type="submit" class="bg-teal-600 hover:bg-teal-700 text-white font-semibold px-5 py-2.5 rounded-xl text-xs shadow-md shadow-teal-900/10 transition">
                    <?php echo e($guru->exists ? 'Simpan Perubahan' : 'Daftarkan Akun'); ?>

                </button>
                <a href="<?php echo e(route('admin.guru-bk.index')); ?>" class="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-xl text-xs font-semibold transition text-center">
                    Batal
                </a>
            </div>
        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $attributes = $__attributesOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $component = $__componentOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__componentOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php /**PATH C:\Users\User\EduCare\resources\views/admin/guru_bk/form.blade.php ENDPATH**/ ?>