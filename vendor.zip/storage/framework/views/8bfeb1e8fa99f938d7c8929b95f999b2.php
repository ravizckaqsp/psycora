<?php if (isset($component)) { $__componentOriginal4fa4e2756a89e38e0ed3781fffbdc081 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4fa4e2756a89e38e0ed3781fffbdc081 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.siswa-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('siswa-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('pageTitle', null, []); ?> Kuesioner Psikososial <?php $__env->endSlot(); ?>
     <?php $__env->slot('pageSubtitle', null, []); ?> Tiga instrumen terintegrasi untuk analisis risiko <?php $__env->endSlot(); ?>

    
    <div class="max-w-2xl mx-auto">
        <div class="text-center mb-8">
            <div class="inline-flex items-center gap-2 bg-violet-100 text-violet-700 text-xs font-semibold px-4 py-2 rounded-full mb-4">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                </svg>
                Kuesioner Tervalidasi Secara Klinis
            </div>
            <h2 class="text-2xl font-bold text-slate-800 mb-2">Kenali Kondisi Psikososialmu</h2>
            <p class="text-slate-500 text-sm max-w-md mx-auto leading-relaxed">
                Jawab 52 pertanyaan dari 3 instrumen berbeda.
            </p>
            <p class="text-slate-500 text-sm max-w-md mx-auto leading-relaxed">
                Estimasi waktu: <strong class="text-slate-700">5-10 menit</strong>.
            </p>
        </div>

        
        <div class="space-y-4 mb-8">
            <?php
                $instruments = [
                    [
                        'key'   => 'SDQ',
                        'title' => 'Strengths & Difficulties Questionnaire',
                        'desc'  => 'Mengukur kekuatan dan kesulitan perilaku, emosi, dan hubungan sosial.',
                        'items' => 25,
                        'color' => 'violet',
                        'icon'  => '🧠',
                        'subscales' => ['Emosi', 'Perilaku', 'Hiperaktivitas', 'Teman Sebaya', 'Prososial'],
                    ],
                    [
                        'key'   => 'PSC-17',
                        'title' => 'Pediatric Symptom Checklist',
                        'desc'  => 'Mendeteksi gejala psikososial: masalah emosi, perhatian, dan perilaku.',
                        'items' => 17,
                        'color' => 'pink',
                        'icon'  => '💙',
                        'subscales' => ['Internalizing', 'Attention', 'Externalizing'],
                    ],
                    [
                        'key'   => 'SAS-SV',
                        'title' => 'Smartphone Addiction Scale – Short Version',
                        'desc'  => 'Mengukur tingkat ketergantungan dan adiksi penggunaan smartphone.',
                        'items' => 10,
                        'color' => 'sky',
                        'icon'  => '📱',
                        'subscales' => ['Daily Life Disturbance', 'Anticipation', 'Withdrawal'],
                    ],
                ];
                $colorMap = [
                    'violet' => ['bg'=>'bg-violet-50','border'=>'border-violet-200','badge'=>'bg-violet-400','text'=>'text-violet-700','tag'=>'bg-violet-100 text-violet-600'],
                    'pink'   => ['bg'=>'bg-pink-50',  'border'=>'border-pink-200',  'badge'=>'bg-pink-400',  'text'=>'text-pink-700',  'tag'=>'bg-pink-100 text-pink-600'],
                    'sky'    => ['bg'=>'bg-sky-50',   'border'=>'border-sky-200',   'badge'=>'bg-sky-400',   'text'=>'text-sky-700',   'tag'=>'bg-sky-100 text-sky-600'],
                ];
            ?>

            <?php $__currentLoopData = $instruments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $inst): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $c = $colorMap[$inst['color']]; ?>
                <div class="<?php echo e($c['bg']); ?> <?php echo e($c['border']); ?> border rounded-2xl p-5">
                    <div class="flex items-start gap-4">
                        <div class="<?php echo e($c['badge']); ?> w-12 h-12 rounded-xl flex items-center justify-center text-xl flex-shrink-0 shadow-sm text-white">
                            <?php echo e($inst['icon']); ?>

                        </div>
                        <div class="flex-1 min-w-0">
                            <div class="flex items-center gap-2 flex-wrap">
                                <span class="<?php echo e($c['badge']); ?> text-white text-xs font-bold px-2 py-0.5 rounded-md"><?php echo e($inst['key']); ?></span>
                                <h3 class="text-sm font-bold text-slate-800"><?php echo e($inst['title']); ?></h3>
                            </div>
                            <p class="text-xs text-slate-500 mt-1 mb-3"><?php echo e($inst['desc']); ?></p>
                            <div class="flex flex-wrap gap-1.5">
                                <?php $__currentLoopData = $inst['subscales']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="<?php echo e($c['tag']); ?> text-[10px] font-medium px-2 py-0.5 rounded-full"><?php echo e($sub); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <span class="bg-slate-100 text-slate-500 text-[10px] font-medium px-2 py-0.5 rounded-full"><?php echo e($inst['items']); ?> soal</span>
                            </div>
                        </div>
                        <div class="flex-shrink-0 text-right">
                            <p class="<?php echo e($c['text']); ?> text-xl font-bold"><?php echo e($inst['items']); ?></p>
                            <p class="text-xs text-slate-400">soal</p>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        
        <div class="bg-blue-50 border border-blue-200 rounded-2xl p-4 mb-6">
            <div class="flex gap-3">
                <svg class="w-5 h-5 text-blue-500 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                    <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd"/>
                </svg>
                <div>
                    <p class="text-sm font-semibold text-blue-800 mb-1">Perhatian</p>
                    <ul class="text-xs text-blue-700 space-y-1 list-disc list-inside">
                        <li>Jawablah dengan jujur sesuai kondisi kamu sebenarnya</li>
                        <li>Jawaban tersimpan otomatis setiap soal (autosave)</li>
                        <li>Kamu bisa kembali ke soal sebelumnya</li>
                        <li>Hasil kuesioner bersifat rahasia</li>
                    </ul>
                </div>
            </div>
        </div>

        <?php if(!$canStart): ?>
            <div class="bg-amber-50 border border-amber-200 rounded-2xl p-4 mb-4 flex items-start gap-3 shadow-sm">
                <span class="text-2xl mt-0.5">⏳</span>
                <div class="flex-1">
                    <p class="text-sm font-semibold text-amber-800">Batas Pengisian Kuesioner</p>
                    <p class="text-xs text-amber-600 leading-relaxed">
                        Kamu hanya dapat mengisi kuesioner sekali dalam 7 hari untuk menjaga akurasi hasil skrining.
                    </p>
                    <p class="text-xs text-amber-700 font-semibold mt-1">
                        Kamu bisa mengisi kuesioner kembali pada: <?php echo e($nextAllowedAt?->format('d F Y, H:i')); ?> WIB
                    </p>
                </div>
            </div>
        <?php endif; ?>

        <?php if($draft): ?>
            <div class="bg-amber-50 border border-amber-200 rounded-2xl p-4 mb-4 flex items-center gap-3 shadow-sm">
                <span class="text-2xl">📝</span>
                <div class="flex-1">
                    <p class="text-sm font-semibold text-amber-800">Draf Kuesioner Tersimpan</p>
                    <p class="text-xs text-amber-600">Kamu memiliki pengisian kuesioner yang belum diselesaikan.</p>
                </div>
                <a href="<?php echo e(route('siswa.questionnaire.sdq')); ?>"
                class="text-xs bg-amber-500 text-white px-3.5 py-2 rounded-lg font-semibold hover:bg-amber-600 transition flex-shrink-0 shadow-sm">
                    Lanjutkan Pengisian
                </a>
            </div>
        <?php endif; ?>

        <?php if($existing): ?>
            <div class="bg-emerald-50 border border-emerald-200 rounded-2xl p-4 mb-4 flex items-center gap-3 shadow-sm">
                <span class="text-2xl">✅</span>
                <div class="flex-1">
                    <p class="text-sm font-semibold text-emerald-800">Kuesioner sebelumnya tersedia</p>
                    <p class="text-xs text-emerald-600">Terakhir: <?php echo e($existing->completed_at?->format('d M Y, H:i')); ?></p>
                </div>
                <a href="<?php echo e(route('siswa.riwayat.show', $existing->id)); ?>"
                class="ml-auto text-xs bg-emerald-500 text-white px-3.5 py-2 rounded-lg font-semibold hover:bg-emerald-600 transition flex-shrink-0 shadow-sm">
                    Lihat Hasil
                </a>
            </div>
        <?php endif; ?>

        
        <?php if(!$canStart): ?>
            <?php if($draft): ?>
                <button type="button" disabled
                   class="block w-full bg-slate-100 text-slate-400 text-center font-bold py-4 rounded-2xl cursor-not-allowed text-base">
                    Hapus draf & mulai baru (terkunci)
                </button>
            <?php else: ?>
                <button type="button" disabled
                   class="block w-full bg-slate-100 text-slate-400 text-center font-bold py-4 rounded-2xl cursor-not-allowed text-base">
                    Mulai kuesioner baru (terkunci)
                </button>
            <?php endif; ?>
        <?php else: ?>
            <?php if($draft): ?>
                <a href="<?php echo e(route('siswa.questionnaire.sdq', ['new' => 'true'])); ?>"
                   onclick="return confirm('Apakah Anda yakin ingin menghapus draf jawaban sebelumnya dan memulai dari awal?')"
                   class="block w-full bg-slate-200 text-slate-700 text-center font-bold py-4 rounded-2xl hover:bg-slate-300 active:scale-[.98] transition-all duration-200 text-base">
                    Hapus draf & mulai baru
                </a>
            <?php else: ?>
                <a href="<?php echo e(route('siswa.questionnaire.sdq', ['new' => 'true'])); ?>"
                   class="block w-full bg-violet-400 text-white text-center font-bold py-4 rounded-2xl shadow-lg shadow-violet-100 hover:shadow-violet-200 active:scale-[.98] transition-all duration-200 text-base">
                    <?php echo e($existing ? 'Mulai kuesioner baru' : 'Mulai kuesioner sekarang'); ?>

                </a>
            <?php endif; ?>
        <?php endif; ?>
        <p class="text-center text-xs text-slate-400 mt-3">Estimasi waktu:
             5-10 menit · 52 soal total</p>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4fa4e2756a89e38e0ed3781fffbdc081)): ?>
<?php $attributes = $__attributesOriginal4fa4e2756a89e38e0ed3781fffbdc081; ?>
<?php unset($__attributesOriginal4fa4e2756a89e38e0ed3781fffbdc081); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4fa4e2756a89e38e0ed3781fffbdc081)): ?>
<?php $component = $__componentOriginal4fa4e2756a89e38e0ed3781fffbdc081; ?>
<?php unset($__componentOriginal4fa4e2756a89e38e0ed3781fffbdc081); ?>
<?php endif; ?>
<?php /**PATH C:\Users\User\EduCare\resources\views/siswa/questionnaire/index.blade.php ENDPATH**/ ?>