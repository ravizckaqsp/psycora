<?php if (isset($component)) { $__componentOriginal4fa4e2756a89e38e0ed3781fffbdc081 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4fa4e2756a89e38e0ed3781fffbdc081 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.siswa-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('siswa-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('pageTitle', null, []); ?> Riwayat Kuesioner <?php $__env->endSlot(); ?>
     <?php $__env->slot('pageSubtitle', null, []); ?> Pantau perkembangan kondisi psikososialmu dari waktu ke waktu <?php $__env->endSlot(); ?>

    <?php
        $riskBadge = [
            'Tidak Berisiko Psikososial' => 'bg-emerald-100 text-emerald-700 border-emerald-200',
            'Berisiko Psikososial'       => 'bg-red-100 text-red-700 border-red-200',
        ];
    ?>

    
    <?php if($chartData->count() > 1): ?>
        <div class="bg-white rounded-2xl p-5 border border-slate-100 shadow-sm mb-6">
            <div class="flex items-center justify-between mb-4">
                <p class="text-sm font-semibold text-slate-700">Grafik Perkembangan Skor</p>
                <span class="text-xs text-slate-400"><?php echo e($chartData->count()); ?> kuesioner</span>
            </div>
            <div class="h-56">
                <canvas id="historyChart"></canvas>
            </div>
        </div>
    <?php endif; ?>

    
    <?php if($responses->count() > 0): ?>
        <div class="space-y-3">
            <?php $__currentLoopData = $responses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $resp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $risk = $resp->riskClassification?->overall_risk ?? '-';
                    $badge = $riskBadge[$risk] ?? 'bg-slate-100 text-slate-500 border-slate-200';
                ?>
                <a href="<?php echo e(route('siswa.riwayat.show', $resp->id)); ?>"
                   class="flex items-center gap-4 bg-white rounded-2xl p-4 sm:p-5 border border-slate-100 shadow-sm hover:shadow-md hover:border-violet-200 transition-all duration-200 group">

                    
                    <div class="w-10 h-10 rounded-xl bg-violet-100 flex items-center justify-center text-violet-700 font-bold text-sm flex-shrink-0">
                        <?php echo e($responses->firstItem() + $loop->index); ?>

                    </div>

                    
                    <div class="flex-1 min-w-0">
                        <div class="flex items-center gap-2 flex-wrap">
                            <p class="text-sm font-semibold text-slate-800">
                                <?php echo e($resp->completed_at?->format('d F Y')); ?>

                            </p>
                            <span class="text-xs text-slate-400"><?php echo e($resp->completed_at?->format('H:i')); ?> WIB</span>
                        </div>
                        <div class="flex items-center gap-3 mt-1.5 flex-wrap">
                            <span class="text-xs text-slate-500 font-medium">SDQ: <strong class="text-slate-700"><?php echo e($resp->sdq_score); ?></strong></span>
                            <span class="text-slate-300">·</span>
                            <span class="text-xs text-slate-500 font-medium">PSC-17: <strong class="text-slate-700"><?php echo e($resp->psc17_score); ?></strong></span>
                            <span class="text-slate-300">·</span>
                            <span class="text-xs text-slate-500 font-medium">SAS-SV: <strong class="text-slate-700"><?php echo e($resp->sassv_score); ?></strong></span>
                        </div>
                    </div>

                    
                    <div class="flex items-center gap-2 flex-shrink-0">
                        <span class="hidden sm:inline-flex px-3 py-1 rounded-full text-xs font-semibold border <?php echo e($badge); ?>">
                            <?php echo e($risk); ?>

                        </span>
                        <svg class="w-5 h-5 text-slate-300 group-hover:text-violet-500 transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/>
                        </svg>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        
        <div class="mt-6">
            <?php echo e($responses->links()); ?>

        </div>

    <?php else: ?>
        
        <div class="bg-white rounded-2xl border border-slate-100 shadow-sm p-12 text-center">
            <div class="text-5xl mb-4">📋</div>
            <h3 class="text-lg font-bold text-slate-700 mb-2">Belum ada riwayat</h3>
            <p class="text-slate-400 text-sm mb-6 max-w-xs mx-auto">Selesaikan kuesioner pertama untuk mulai memantau perkembangan psikososialmu.</p>
            <a href="<?php echo e(route('siswa.questionnaire.index')); ?>"
               class="inline-flex items-center gap-2 bg-violet-400 text-white font-bold px-6 py-3 rounded-xl shadow-md shadow-violet-100 hover:shadow-lg transition text-sm">
                Mulai kuesioner
            </a>
        </div>
    <?php endif; ?>

    <?php $__env->startPush('scripts'); ?>
    <?php if($chartData->count() > 1): ?>
    <script>
    new Chart(document.getElementById('historyChart'), {
        type: 'line',
        data: {
            labels: <?php echo json_encode($chartData->map(fn($d) => \Carbon\Carbon::parse($d->completed_at)->format('d M')), 15, 512) ?>,
            datasets: [
                { label: 'SDQ',    data: <?php echo json_encode($chartData->pluck('sdq_score'), 15, 512) ?>,    borderColor:'#a78bfa', backgroundColor:'rgba(167,139,250,0.07)', tension:.4, fill:true,  pointBackgroundColor:'#a78bfa', pointRadius:5, pointHoverRadius:7 },
                { label: 'PSC-17', data: <?php echo json_encode($chartData->pluck('psc17_score'), 15, 512) ?>,  borderColor:'#f472b6', backgroundColor:'transparent', tension:.4, fill:false, pointBackgroundColor:'#f472b6', pointRadius:5, pointHoverRadius:7 },
                { label: 'SAS-SV', data: <?php echo json_encode($chartData->pluck('sassv_score'), 15, 512) ?>,  borderColor:'#38bdf8', backgroundColor:'transparent', tension:.4, fill:false, pointBackgroundColor:'#38bdf8', pointRadius:5, pointHoverRadius:7 },
            ]
        },
        options: {
            responsive: true, maintainAspectRatio: false,
            interaction: { mode: 'index', intersect: false },
            plugins: { legend: { labels: { font: { size:11, family:'Inter' }, padding:16, boxWidth:10, usePointStyle:true }}},
            scales: {
                x: { grid: { display:false }, ticks: { font:{ size:11 }}},
                y: { grid: { color:'#f1f5f9' }, beginAtZero:true, ticks: { font:{ size:11 }}}
            }
        }
    });
    </script>
    <?php endif; ?>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4fa4e2756a89e38e0ed3781fffbdc081)): ?>
<?php $attributes = $__attributesOriginal4fa4e2756a89e38e0ed3781fffbdc081; ?>
<?php unset($__attributesOriginal4fa4e2756a89e38e0ed3781fffbdc081); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4fa4e2756a89e38e0ed3781fffbdc081)): ?>
<?php $component = $__componentOriginal4fa4e2756a89e38e0ed3781fffbdc081; ?>
<?php unset($__componentOriginal4fa4e2756a89e38e0ed3781fffbdc081); ?>
<?php endif; ?>
<?php /**PATH C:\Users\User\EduCare\resources\views/siswa/riwayat/index.blade.php ENDPATH**/ ?>